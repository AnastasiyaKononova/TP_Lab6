//
//  Analyser.h
//  Lab6_1
//
//  Created by Admin on 11.04.16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Analyser : NSObject
- (void)foo:(NSString *)bar;
@end
